function out = identderiv(in)

% Derivative of identity function, simply return 1 (one).

out = ones(size(in));

end
