function out = sigmoid(in)

%Compute sigmoid function.

out = 1.0 ./ (1.0 + exp(-in));

end
