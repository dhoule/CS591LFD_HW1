function out = ident(in)

% Identity, simply return input as output.

out = in;

end
